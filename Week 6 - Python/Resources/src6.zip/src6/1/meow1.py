# Demonstrates while loop

i = 0
while i < 3:
    print("meow")
    i += 1
