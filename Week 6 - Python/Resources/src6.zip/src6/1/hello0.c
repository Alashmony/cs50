// A program that says hello to the world

#include <stdio.h>

int main(void)
{
    printf("hello, world\n");
}
