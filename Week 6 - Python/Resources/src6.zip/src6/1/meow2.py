# Opportunity for better design

for i in [0, 1, 2]:
    print("meow")
