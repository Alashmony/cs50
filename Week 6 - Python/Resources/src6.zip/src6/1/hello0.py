# A program that says hello to the world

print("hello, world")
