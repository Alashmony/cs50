# Uppercases string all at once

before = input("Before: ")
after = before.upper()
print(f"After:  {after}")
