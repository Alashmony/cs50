text = "In the great green room"

for word in text.split():
    for c in word:
        print(c)
