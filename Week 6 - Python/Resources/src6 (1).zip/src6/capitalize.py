text = input("Enter a string: ")
text = text.capitalize()
print(text)
