text = "In the great green room"
text = text.split()
print(words[1:2])
