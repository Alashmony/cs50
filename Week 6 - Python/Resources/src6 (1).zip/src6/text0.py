text = "In the great green room"

for word in text.split():
    print(word)
