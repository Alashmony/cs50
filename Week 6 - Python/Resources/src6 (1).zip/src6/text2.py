text = "In the great green room"

for word in text.split():
    if "g" in word:
        print(word)
