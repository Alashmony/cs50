text = "In the great green room"

for word in text.split()[2:]:
    print(word)
